package test.java.com.akg.util.rpncalculator;

import org.junit.Test;
import junit.framework.TestCase;
import main.java.com.akg.util.rpncalculator.RPNCalculator;

public class RPNCalculatorTest extends TestCase{
	
	/**
	 * Test undo functionality.
	 * @throws Exception
	 */
    @Test
    public void testInsufficientParameterException() throws Exception {
    	RPNCalculator.calculate("clear");
        assertEquals(RPNCalculator.calculate("1 2 3 * 5 + * * 6 5"), 
        		RPNCalculator.displayDoubleValue(Double.valueOf(11)));
    }
	/**
	 * Test undo functionality.
	 * @throws Exception
	 */
    @Test
    public void testDisplayStateRPNCalculator() throws Exception {
    	RPNCalculator.calculate("clear");
    	RPNCalculator.calculate("5 4 3 2 * * *");
        assertEquals(RPNCalculator.displayState(), "stack: 120");
    }
	/**
	 * Test undo functionality.
	 * @throws Exception
	 */
    @Test
    public void testUndoRPNCalculator() throws Exception {
        assertEquals(RPNCalculator.calculate("2 undo"), "" );
        assertEquals(RPNCalculator.calculate("5 4 3 2 undo undo *"),
        		RPNCalculator.displayDoubleValue(Double.valueOf(20)));
        RPNCalculator.calculate("clear");
        RPNCalculator.calculate("20");
        assertEquals(RPNCalculator.calculate("5 *"),  
        		RPNCalculator.displayDoubleValue(Double.valueOf(100)));
        assertEquals(RPNCalculator.calculate("undo"), 
        		RPNCalculator.displayDoubleValue(Double.valueOf(20)));
    }
	/**
	 * Test clear functionality.
	 * @throws Exception
	 */
    @Test
    public void testClearRPNCalculator() throws Exception {
        assertEquals(RPNCalculator.calculate("2 16 18 7 clear"), "" );
        assertEquals(RPNCalculator.calculate("2 16 + 18 7 + - clear"), "" );
    }
    
	/**
	 * Test square root functionality.
	 * @throws Exception
	 */
    @Test
    public void testSquareRootRPNCalculator() throws Exception {
        assertEquals(RPNCalculator.calculate("2 sqrt"), 
        		RPNCalculator.displayDoubleValue(Double.valueOf(1.4142135623730951)));
        assertEquals(RPNCalculator.calculate("9 sqrt"),
        		RPNCalculator.displayDoubleValue(Double.valueOf(3)));
    }
    
	/**
	 * Test addition functionality.
	 * @throws Exception
	 */
    @Test
    public void testAdditionRPNCalculator() throws Exception {
        assertEquals(RPNCalculator.calculate("128 7 +"), 
        		RPNCalculator.displayDoubleValue(Double.valueOf(135)));
        assertEquals(RPNCalculator.calculate("2 16 + 18 7 + -"), 
        		RPNCalculator.displayDoubleValue(Double.valueOf(-7)));
    }
    
	/**
	 * Test multiplication functionality.
	 * @throws Exception
	 */
    @Test
    public void testMultiplicationRPNCalculator() throws Exception{
        assertEquals(RPNCalculator.calculate("14 17 *"), 
        		RPNCalculator.displayDoubleValue(Double.valueOf(238)));
        assertEquals(RPNCalculator.calculate("14 7 * 5 1 * *"), 
        		RPNCalculator.displayDoubleValue(Double.valueOf(490)));
    }
    
	/**
	 * Test substraction functionality.
	 * @throws Exception
	 */
    @Test
    public void testSubstractionRPNCalculator() throws Exception {
        assertEquals( RPNCalculator.calculate("8 13 -"),
        		RPNCalculator.displayDoubleValue(Double.valueOf(-5)));
        assertEquals( RPNCalculator.calculate("13 2 - 10 90 - -"), 
        		RPNCalculator.displayDoubleValue(Double.valueOf(91)));
    }

	/**
	 * Test division functionality.
	 * @throws Exception
	 */
    @Test
    public void testDivisionRPNCalculator() throws Exception {
        assertEquals( RPNCalculator.calculate( "36 4 / " ), 
        		RPNCalculator.displayDoubleValue(Double.valueOf(9)));
        assertEquals( RPNCalculator.calculate( "190 3 / 30 15 / /" ),
        		RPNCalculator.displayDoubleValue(Double.valueOf(31.666666666666668)));
    }
    
	/**
	 * Test mixed operations functionality.
	 * @throws Exception
	 */
    @Test
    public void testMixOpeartionRPNCalculator() throws Exception{
        assertEquals( RPNCalculator.calculate( "151 7 1 1 + - / 23 * 2 1 201 + + -" ),
        		RPNCalculator.displayDoubleValue(Double.valueOf(490.6)));
    }
}
