package main.java.com.akg.util.rpncalculator;

import java.util.Scanner;
/*
 * Client Application using RPN Calculator
 */
public class Main {

	/*
	 * Scanner to get user's input continuously
	 */
	private static Scanner scanner;

	public static void main(String[] args) {
		scanner = new Scanner(System.in);

		while(scanner.hasNextLine()) {
			/*
			 * RPN Calculator
			 */
			RPNCalculator.calculate(scanner.nextLine());
			
			/*
			 * Calculator output
			 */
			System.out.println(RPNCalculator.displayState());
		}
	}
}
