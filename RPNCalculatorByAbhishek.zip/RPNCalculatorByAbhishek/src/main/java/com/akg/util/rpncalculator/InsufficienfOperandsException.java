package main.java.com.akg.util.rpncalculator;

public class InsufficienfOperandsException extends Exception{

	public InsufficienfOperandsException(String message) {
		super(message);
	}
}
