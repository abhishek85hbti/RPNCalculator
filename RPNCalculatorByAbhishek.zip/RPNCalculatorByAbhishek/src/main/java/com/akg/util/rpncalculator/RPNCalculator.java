package main.java.com.akg.util.rpncalculator;

import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.Stack;
/**
 * RPN Calculator
 * 
 * @author abhigupt
 *
 */
public class RPNCalculator {
	
	/*
	 * Current value stack 
	 */
	private static Stack<Double> state = new Stack<Double>();
	
	/*
	 * Previous value stack before a operation 
	 */
	private static Stack<Double> preStateOne = new Stack<Double>();
	
	/*
	 * Previous value stack before two operation
	 */
	private static Stack<Double> preStateTwo = new Stack<Double>();
	
	/**
	 * Calculator based on RPN' (reverse polish notation) mode.
	 * 
	 * @param state
	 * @param userInputString
	 */
	public static String calculate(String userInputString) {
		
		if (!userInputString.isEmpty()) {
			userInputString = userInputString.trim();
			String userInputs[] = userInputString.split(" ");
			updateStackSates(userInputs);
			
			for(int index=0; index < userInputs.length; index++) {
				String userInput = userInputs[index];
				double[] operands;
				try {
					operands = validateOperators(userInput, index);
				} catch (InsufficienfOperandsException e) {
					System.out.println(e.getMessage());
					break;
				}

				switch(userInput) {
				case "+":
					state.push(operands[0] + operands[1]);
					break;
				case "-":
					state.push(operands[0] - operands[1]);
					break;
				case "*":
					state.push(operands[0] * operands[1]);
					break;
				case "/":
					state.push(operands[0] / operands[1]);
					break;
				case "sqrt":
					state.push(Math.sqrt(state.pop()));
					break;
				case "undo":
					undoStackSates();
					break;
				case "clear":
					clearStackSates();
					break;
				default:
					try {
						double realNumber = Double.parseDouble(userInput);
						state.push(realNumber);
					} catch (NumberFormatException e) {
						System.out.println("Input parameter: " +userInput + " Isn't real number.");
						break;
					}
					break;
				}
			}
		}
		return state.isEmpty() ? "" : displayDoubleValue(state.peek());
	}
	
	/**
	 * Numbers stored on the stack with 16 decimal places of precision and 
	 * formatted as 10 decimal places (or less if it causes no loss of precision)
	 * 
	 * @param state
	 * @return String 
	 */
	public static String displayState() {
		Iterator<Double> it = state.iterator();
		if (! it.hasNext())
			return "stack: ";
		StringBuilder sb = new StringBuilder();
		sb.append("stack: ");
		while (it.hasNext()) {
			DecimalFormat df = new DecimalFormat("#.##########"); 
			String formatted = df.format(it.next()); 
			sb.append(formatted);
			if (it.hasNext())
				sb.append(' ');
		}
		return sb.toString();
	}
	
	/**
	 * Utility method to format a double value as 10 decimal 
	 * places (or less if it causes no loss of precision)
	 * 
	 * @param state
	 * @return String 
	 */
    public static String displayDoubleValue(Double value) {
    	DecimalFormat df = new DecimalFormat("#.##########"); 
    	return df.format(value); 
    }
    
	/**
	 * operator validations
	 * 
	 * @throws InsufficienfOperandsException 
	 * 
	 */
	private static double[] validateOperators(String operator, int index) throws InsufficienfOperandsException {
		
		double[] operands = new double[2];
		if ((operator.equals("+") ||operator.equals("-") ||operator.equals("*") ||operator.equals("/"))) {
			if ((state.size()>1)) {
				operands[1] = state.pop();
				operands[0] = state.pop();
			} else {
				ThrowInsufficienfParametersException(state, operator, index);
			}
		}
		else if (operator.equals("sqrt") && state.isEmpty()) {
			ThrowInsufficienfParametersException(state, operator, index);
		}
		return operands;
	}
	
	/**
	 * Initialize stack states
	 * 
	 * @param operationString
	 * @return
	 */
	private static void updateStackSates(String userInputs[]) {

		boolean isValidInput = false;
		for (String input:userInputs) {
			if (input.equals("+") ||input.equals("-")
					||input.equals("*") ||input.equals("/") 
					||input.equals("sqrt")) {
				isValidInput = true;
			} else {
				try {
					double number = Double.parseDouble(input);
					isValidInput = true;
				} catch (NumberFormatException ex) {
					isValidInput = false;
					break;
				}
			}
		}
		if (isValidInput) {
			preStateTwo = (Stack<Double>) preStateOne.clone();
			preStateOne = (Stack<Double>) state.clone();				
		}
	}
	
	/**
	 * Update stack states while undo operation
	 * 
	 * @param operationString
	 * @return
	 */
	private static void undoStackSates() {
		
		if (!preStateOne.isEmpty()) {
			state = (Stack<Double>) preStateOne.clone();
			preStateOne = (Stack<Double>) preStateTwo.clone();
			preStateTwo.clear();
		} else if (!state.isEmpty()) {
			state.pop();
		} else if (state.isEmpty()) {
			preStateOne.clear();preStateTwo.clear();
		}
	}
	/**
	 * clear stack states
	 * 
	 * @param operationString
	 * @return
	 */
	private static void clearStackSates() {
		state.clear();preStateOne.clear();preStateTwo.clear();
	}
	
	/**
	 * A warning is displayed if an operator cannot find a sufficient number of parameters on the stack
	 * 
	 * @param stack
	 * @param operator
	 * @param operatorPosition
	 */
	private static void ThrowInsufficienfParametersException (Stack<Double> stack, String operator, int pos) throws InsufficienfOperandsException {
		++pos;
		int operatorPosition = (pos < 2) ? pos : (2*pos-1);
		throw new InsufficienfOperandsException("operator "+ operator + " (position: "+ operatorPosition+"): insufficient parameters");
	}
}

