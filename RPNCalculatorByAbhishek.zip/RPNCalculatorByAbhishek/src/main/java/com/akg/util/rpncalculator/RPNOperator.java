package main.java.com.akg.util.rpncalculator;

public enum RPNOperator {
	PLUS("+"),
	MINUS("-"),
	MULTIPLY("*"),
	DIVIDE("/"),
	SQRT("sqrt"),
	CLEAR("claer"),
	UNDO("undo");

    private final String value;

    /**
     * @param value
     */
    RPNOperator(final String str) {
        this.value = str;
    }

    /* (non-Javadoc)
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return value;
    }
}